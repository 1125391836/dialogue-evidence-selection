# TicketTalk 场次盲审

## Q01

00 U  Could you help me get some movie tickets for Sonic the Hedgehog?

01 A  Sure, what theater?

02 U  The AMC.

03 A  Okay and what day is this for?

04 U  Friday afternoon. 3pm.

05 A  Alright and would you like to see it in IMAX, 3D or Standard?

06 U  Hmm. Let's do Standard.

07 A  Alright give me just a moment.

08 U  Sure.

09 A  How many tickets?

10 U  3

11 A  Okay, so I have 3 tickets for Friday afternoon at 3pm to see Sonic the Hedgehog at the AMC in Standard. Is this correct?

12 U  Can we change it from Standard to IMAX.

13 A  Sure thing, give me just a moment.

14 U  Okay.

15 A  Alright I now have 3 tickets to see Sonic the Hedgehog at 3pm Friday afternoon. The movie is showing at the AMC and you want to see it in IMAX. Correct?

16 U  Yep! Please book them.

17 A  Give me one moment.

18 U  Okay. Thanks.

## Q02

00 U  Hi, I would like to see a movie tomorrow night.

01 A  Hello. How can I help you? Could you please let me know what kind of movie you are looking for?

02 U  It for me and my girlfriend, we would like something kind of light-hearted.

03 A  Sure, we have two movies that are comedies: Not My Problem and Family Jewels.

04 U  I think I've heard of Family Jewels...

05 A  Yes, it is a romantic comedy about a diamond dealers that leaves Europe to take on a romance with an American.

06 U  Oh yeah, that's the one. That sounds pretty good. Where is it showing?

07 A  It is showing at the AMC Holiday Theater, Spring Hills Kansas

08 U  OK, I know where that is. I think I can find it.

09 A  Did you have a particular time in mind?

10 U  We'll be having dinner so I'd prefer a later time.

11 A  We have showings at 2, 5 and 8:10pm.

12 U  Hmmm. Let me think. I think I would prefer the 8:10pm time.

13 A  Sure, let me see it it is available. That was for two tickets?

14 U  Yes, just me and my girlfriend.

15 A  Sure, it looks like they are available. Would you like to buy them now.

16 U  Yes, I would like to put them on my credit card.

17 A  OK, so I have two tickets for tomorrow reserved for Family Jewels, at the AMC Holiday Theater for the 8:10pm showing. Is that correct? The total is $XX.XX.

18 U  Yes, that about sums it up. My credit card is XXXXXXXXX, expiration XX.XX. My email is XXXX@XXX.com

## Q03

00 U  Hi, I would like help purchasing movie tickets.

01 A  Sure, where are you calling from?

02 U  Spring Hills Kansas

03 A  Okay, there are two theaters in Spring Hill; Cinemark Downtown and AMC Holiday Theater.

04 U  What is playing at AMC Holiday Theater?

05 A  Not my problem, Family Jewels and Shuttered.

06 U  What is shuttered about?

07 A  Horror - rated R - Rotten Tomatoes 61% - Sarah Decker moves upstate from her New York City lifestyle to work on her distant cousin’s haunted marijuana farm.

08 U  What is family jewels about?

09 A  Romantic Comedy - rated R - Rotten Tomatoes 69% - A famous diamond dealer leaves his European life in Antwerp to pursue a less than genuine romance with an American con artist- Stars Melissa McCarthy and Ryan Reynolds.

10 U  What time is shuttered playing today?

11 A  3:00pm - 5:45 - 9:00pm

12 U  Hmm..What time is family jewels playing today?

13 A  2:00pm - 5:00pm - 8:10pm

14 U  Lets go with Family Jewels at 2pm.

15 A  How many tickets would you like?

16 U  3

17 A  Are you ready for me to purchase three tickets to see Family Jewels at 2pm today at AMC Holiday Theater?

18 U  Yes, make the purchase.

## Q04

00 U  Hello. I'd like you to tell me what comedy or family movies are currently playing at Regal Cinema Harrisburg?

01 A  Do you wish to screen by rating?

02 U  Yes. Only PG or PG-13 rated films, please.

03 A  For what showing date or dates?

04 U  Saturday, January 25th or Sunday, January 26th. Look for afternoon screening times only.

05 A  Okay. Searching for afternoon showings of PG or PG-13 rated comedy or family films at Regal Cinema on Saturday, January 25th or Sunday, January 26th. Do you want me to ignore unrated or foreign language movies?

06 U  Absolutely.

07 A  Okay. Movies which meet your criteria include Doolittle (2020); Spies in Disguise; and Jumanji, The Next Level. Of these, only Doolittle (2020) is rated "PG".

08 U  Tell me more about the film, Spies in Disguise.

09 A  Certainly. Spies in Disguise is an animated action adventure comedy for family audiences.

10 U  Read me a synopsis, please.

11 A  Synopsis. Quote: "Lance is a super cool and charming spy, and Walter invents the super cool gadgets that Lance uses. But when events take an unexpected turn, Walter and Lance suddenly have to rely on each other in a whole new way." Endquote.

12 U  Sounds like fun. I think Spies in Disguise is our movie. Who does it star?

13 A  The lead character of Lance Starling is voiced by actor Will Smith.

14 U  Thanks. Give me afternoon showtimes for both Saturday & Sunday at Regal, please.

15 A  On both Saturday, January 25th and Sunday, January 26th, Spies in Disguise is showing at only at 12:50 PM and 3:25 PM.

16 U  Okay. Book 1 adult and 2 child tickets for Spies in Disguise on Sunday at 3:25 PM, please.

17 A  Accessing Fandango. Booking 1 adult and 2 child tickets to Spies in Disguise...

18 U  Wait. I need 1 senior ticket, too. Order 1 adult, 1 senior and 2 child tickets for Sunday the 26th.

19 A  Ordering 1 adult, 1 senior and 2 child tickets to the 3:25 PM showing of Spies in Disguise at Regal Cinema for Sunday, January 26th. Is that correct?

20 U  Yes. Use my preferred Visa card.

21 A  Confirming one adult ticket at $11.70 each; one senior ticket and 2 child tickets at $8.50 each, with an added $7.16 convenience fee for a total preferred Visa charge of $44.36. Shall I complete payment?

22 U  Yes. No gift cards or promo codes.

## Q05

00 U  Hi, I'd like some help with a couple of film titles.

01 A  Sure, what do you need?

02 U  I am looking for a title for one of the films and I'm also looking for critic scores for both films.

03 A  Alright, I can help with that. What are the titles of the films?

04 U  Well, one I don't know the name of, but the other one is called Shuttered.

05 A  Okay, Let's get Shuttered out of the way first. That film has a critic score of 61%.

06 U  Okay great. The other film I'm not sure of the title but I do know it stars Matt Damon. It's one of his new films.

07 A  Okay, I found it. It's called Not My Problem. It has a score of 72%.

08 U  Great. I think I'll opt for the Matt Damon film, can you help me book tickets?

09 A  Sure, just let me know what your location is.

10 U  I'm in Spring Hills Kansas.

11 A  I have Not My Problem playing at AMC Holiday Theater in your area.

12 U  Cool, what are the show times?

13 A  Not My Problem is playing at 1pm, 3:55pm, 7pm and 10:05pm.

14 U  I'll take the 7pm show times please.

15 A  Alright, how many tickets do you need?

16 U  Just one.

17 A  Great, Let me confirm your order. You have 1 ticket to see Not My Problem at the AMC Holiday theater at 7pm tonight right?

18 U  Yup, that's everything.

## Q06

00 U  I would like to see a movie tonight.

01 A  Great I can help you order some tickets!

02 U  That would be great.

03 A  What would you like to see?

04 U  I want to see Star wars.

05 A  What theater would you like to go to?

06 U  The nearest Regal cinemas theater would be good.

07 A  What time would you like to go?

08 U  8:30 PM if possible.

09 A  What kind of screening would you like?

10 U  IMAX.

11 A  How many tickets do you need?

12 U  2 please.

13 A  There are no IMAX showings for Star wars at that time.

14 U  How about other screening types?

15 A  There is one for 3D and standard.

16 U  I'll take the 3D one instead then.

17 A  I'll go ahead and book the 2 tickets for the 8:30 showing for Star wars 3D screening.

18 U  Yes thank you.

## Q07

00 U  I want to see a movie tonight with more interests.

01 A  OK. And where will you be seeing the movie?

02 U  Creek's End,Oregon.

03 A  Creek’s End, Oregon. Got it. Is there a particular movie you have in mind?

04 U  Mulan with my kids.

05 A  Sure. Disney seems like a great choice. In Creek’s End, Oregon, I see that Mulan is showing in two theaters: AMC Mountain 16 and AMC Mercado 24.

06 U  You know i prefer AMC Mercado 24 because it was closer to me.

07 A  No problem. It looks like tonight’s remaining showtimes for Mulan at AMC Mercado 24 are 5:00pm, 7:10pm, and 9:45pm. Which is best for you?

08 U  I choose 5:00pm

09 A  Great. And how many tickets?

10 U  three

11 A  All right. Let me confirm that you’d like three tickets for Mulan at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

12 U  yes,correct.

13 A  Is it OK to go ahead and purchase these tickets?

14 U  Yeah.okay.

## Q08

00 U  I would like to purchase movie tickets to a chowing tonight.

01 A  OK. Can you tell me the city and state where the theater is located?

02 U  I would like a theater somewhere in Santa Barbra, California.

03 A  I see two theaters, AMC Mountain 16 and AMC Mercado 24. Are you interested in a particular movie?

04 U  Both of those theaters have always been great, in my experience.

05 A  OK. Is there a movie you have in mind?

06 U  I'm not sure. I have no clue what movies are currently playing.

07 A  Sure. Do you have a favorite genre?

08 U  what is a genre?

09 A  Genre the movie category, like comedy, drama, action, etc.

10 U  Oh, I get what genre means now, thanks! I love action movies.

11 A  Ok. Let’s see what action films are out.

12 A  I found one action movie at AMC Mountain 16: No Time To Die.

13 U  when is No Time to Die playing?

14 A  One moment.

15 U  The one at 9:10 pm sounds like it would work.

16 A  Got it. And how many tickets?

17 U  enough for me and two of my friends.

18 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

19 U  yes, I'll confirm that.

20 A  Is it OK to go ahead and purchase these tickets?

21 U  Yes please.

## Q09

00 U  i want a movie tickets?

01 A  OK. Do you have anything in mind?

02 U  no i dont have

03 A  Sure. And what city are you looking in?

04 U  brando city ,texas state

05 A  Brando, Texas. Got it. And is there a particular type of movie you’d like to see?

06 U  i like horror movies and action movies

07 A  A few titles playing in your area are No Time To Die, Mulan, and Stella’s House.

08 U  wow.stellas house playing in screen,i heard that movie is very exciting? who is the director of that movie?

09 A  The director of Stella’s House is Clyde Stewart.

10 U  ohh..super i already know about him talents in social medias.ttell me show times and thatre details.

11 A  OK. Stella’s House is playing at the Milford Theater. Showtimes are 4:40pm, 7:10pm, and 9:30pm. Which one would you prefer?

12 U  yup.sorry urgent call from ofiice plase can you change tickets tomorrow

13 A  No problem. Let me the showtimes for tomorrow.

14 A  OK. The showtimes for tomorrow are the same. Which one should I book?

15 U  last showing time?

16 A  Sure. The last showing is 9:30pm.

17 U  okay choose that time.

18 A  All right. Let me confirm. You’d like 4 tickets for the 9:30pm showing of Stella’s House at Milford Theater tomorrow. Is that all correct?

19 U  okay

20 A  Is it OK to go ahead and purchase these tickets?

21 U  ok good.

## Q10

00 U  What's playing tonight?

01 A  Where would you like to go?

02 U  Cinemark downtown

03 A  Tonight is playing Back Country and Beyond the storm

04 U  Which one has a better rating?

05 A  Backcountry has a better rating on rotten tomateos

06 U  What are the genres?

07 A  Backcountry is a documentary and beyond the storm is action

08 U  Lets go with beyond the storm

09 A  How many tickets would you like

10 U  3 please

11 A  Is it for today?

12 U  Yes

13 A  The viewing times today are 1:30pm - 3:40 - 6:10pm - 8:30pm

14 U  Let's do 6:10 pm please

15 A  Just to confirm thats 3 tickets today at the Cinemark Downtown cinema 6:10 pm viewing time of Beyond the Storm, are these details correct?

16 U  Yes thank you

17 A  Provide your email for confirmation

18 U  info@info.com

## Q11

00 U  I'm looking to check out a few new flicks near me. What is playing that is rated PG-13 or lower?

01 A  What is your location?

02 U  I am in Spring Hills Kansas.

03 A  OK. Near Spring Hills, Beyond the Storm, Backcountry, and Not My Problem are all playing.

04 U  OK. What is the rating for Beyond the Storm?

05 A  Beyond the Storm has a PG-13 rating.

06 U  What is it about?

07 A  Beyond the Storm follows fishing in the Northern Sea under Captain John as things get ugly.

08 U  What kind of a film is it?

09 A  It is an action film.

10 U  What about Not My Problem, who is in that?

11 A  Noah Schnapp and Matt Damon star in Not My Problem.

12 U  OK, is it playing in Hill Springs, Kansas on August 20, 2020?

13 A  Yes, it is. Not My Problem plays at AMC Holiday Theater at 1:00 PM, 3:55 PM, 7:00 PM, and 10:05 PM.

14 U  What is the Rotten Tomatoes score for Not My Problem?

15 A  The Rotten Tomatoes score for Not My Problem is 72%.

16 U  OK, can I get four tickets to see Not My Problem at AMC Holiday Theater for August 20, 2020 at 7:00 PM?

17 A  So to confirm, you want four tickets for Not My Problem at AMC Holiday Theater for the 7:00 PM showing on August 20, 2020, is that correct?

18 U  Yes, that is right. You can confirm the tickets.

## Q12

00 U  I was told that the movie, The Gentlemen is an interesting one. Can you tell me something about it?

01 A  I would love to. The Gentlemen is a 2019 action comedy film written and directed by Guy Ritchie, from a story by Ivan Atkinson, Marn Davies, and Ritchie. The film stars Matthew McConaughey, Charlie Hunnam, Henry Golding, Michelle Dockery, Jeremy Strong, Eddie Marsan, Colin Farrell and Hugh Grant.

02 U  What is 1917 about?

03 A  It is a drama and an action film. During World War I, two British soldiers -- Lance Cpl. Schofield and Lance Cpl. Blake -- receive seemingly impossible orders. In a race against time, they must cross over into enemy territory to deliver a message that could potentially save 1,600 of their fellow comrades -- including Blake's own brother.

04 U  I think I will watch The Gentlemen. Is it showing in the fort worth area?

05 A  I have 5 theaters showing it in fort worth. Any particular movie theater you're interested in?

06 U  My mom and I like going to the Movie Tavern West 7th.

07 A  The last show tonight at Movie Tavern West 7th is at 9:00 PM.

08 U  I still have time. Book me for 2 please.

09 A  Any screening preference?

10 U  I'll take 3D.

11 A  Unfortunately we just have it on standard screening.

12 U  Standard screening is fine.

13 A  So let me reserve you 2 tickets for The Gentlemen on standard screening at Movie Tavern West 7th at the 9:00 PM show.

14 U  Great! My mom will surely love that.

15 A  I am booking it as we speak. Your confirmation is 12345.

16 U  Thank you.

## Q13

00 U  Would you mind booking some movie tickets for me for tonight?

01 A  Not at all, where should I search?

02 U  Look in Spring Hills, Kansas.

03 A  Got it, and what movie did you want to look at times for?

04 U  I wanted to watch Backcountry but my friend wants to watch Shuddered, which one got better reviews?

05 A  Between Backcountry and Shuddered, Backcountry got significantly better reviews from critics.

06 U  Great, can you look for times for that movie?

07 A  Sure, which theater would you like to look for times in?

08 U  I'm closest to Cinemark Downtown.

09 A  Got it, and what time frame were you looking at?

10 U  Sometime between 7 and 8PM.

11 A  How many tickets will you need?

12 U  I just need 2 tickets.

13 A  Ok, so I found a 7:30PM showing for Backcountry playing at Cinemark Downtown, does that sound ok?

14 U  Yup, that's perfect!

15 A  Would you like me to book those?

16 U  Yes please.

## Q14

00 U  Hello. I would like to get some tickets to the movies for this evening.

01 A  OK. Can you tell me the city and state where the theater is located?

02 U  It has been so long since I last went to the movies. I cannot wait!

03 A  Great. Can you tell me the city and state where you plan to see the movie?

04 U  I'm in Santa Barbara, Califonia.

05 A  Got it. Are you interested in a particular movie?

06 U  There are actually a few theaters to pick from in my town.

07 A  OK. Is there a movie you have in mind?

08 U  Are there any action movies playing?

09 A  Ok. Let’s see what action films are out in that area.

10 A  I found one action movie at AMC Mountain 16: No Time To Die. Are you interested in that one?

11 U  My closest buddy love action! I have even noticed that action films seem to be way more well-liked than they used to be.

12 A  OK. Are you interested in this movie though?

13 U  Yes. Can you run the details past me?

14 A  OK. Remaining showtimes for No Time To Die at AMC Mountain 16 are 4:30pm, 6:40pm and 9:10pm.

15 U  I'll take the 9:10pm.

16 A  Got it. And how many tickets?

17 U  It's going to be my two best girlfriends and I.

18 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

19 U  I am so excited to see No Time to Die!

20 A  I hear you. Can you confirm the details are correct?

21 U  Oh, yes they are.

22 A  Awesome. Is it OK to go ahead and purchase these tickets?

23 U  Yeah, let's do it.

## Q15

00 U  Hello, I want to go watch a movie in theaters today.

01 A  Hi there! What movie would you like to see?

02 U  I want to go see No Time to Die with my friend - get 2 tickets please.

03 A  Sounds good! Which movie would you like to go to?

04 U  What is the closest one to me?

05 A  I found one theater nearby in Hillview, Oregon: Mountain AMC 16. Would you like to see showtimes there for No Time to Die?

06 U  Yes! That's the only one in town.

07 A  Showtimes for No Time to Die are 3:00pm, 5:10pm, 7:30pm, and 9:40pm.

08 U  Ok, let's do the 3PM show.

09 A  Great! Just to confirm, you would like to purchase 2 tickets to No Time to Die at Mountain AMC 16 at 3:00 PM?

10 U  Hold on, I remember my friend really enjoyed Disney movies when she was younger. She might like to see Mulan instead.

11 A  Ok, would you like to see showtimes for Mulan?

12 U  Yes, let's see if there's a similar time we can go see that instead.

13 A  Showtimes for Mulan are 4:00pm, 6:10pm, 8:30pm, and 10:40pm.

14 U  4PM is perfect!

15 A  Ok, can you confirm that you would like to purchase 2 tickets to Mulan at Mountain AMC 16 at 4PM?

16 U  Yes, confirmed!

## Q16

00 U  Can I get some assistance please?

01 A  Sure what can I help you with for today?

02 U  I need some info on a couple of movies for today in Spring Hills Kansas.

03 A  Okay today in Spring Hills Kansas, which movies can I get info for?

04 U  Not My Problem is one and the other is Family Jewels.

05 A  Okay hold for a second while I get that !

06 U  No problem !

07 A  Okay first we have Not My Problem - Comedy - rated PG-13 - Rotten Tomatoes 72% - A troubled teen tries to convince his depressed elderly neighbor that things are not what they seem. - Stars Matt Damon and Noah Schnapp.

08 U  I'm not a Matt Damon fan, what about the other?

09 A  Family Jewels - Romantic Comedy - rated R - Rotten Tomatoes 69% - A famous diamond dealer leaves his European life in Antwerp to pursue a less than genuine romance with an American con artist- Stars Melissa McCarthy and Ryan Reynolds.

10 U  I want to see that one I think.

11 A  I can book that for you all I would need is party size and the theater time.

12 U  Party size is just two and what are my time slots for that movie?

13 A  Family Jewels: AMC Holiday Theater - 2:00pm - 5:00pm - 8:10pm.

14 U  Okay lets book two for 2 pm and that theater is close so that works.

15 A  Booking two for 2 pm and that theater is fine. Is that correct?

16 U  Yes perfect.

## Q17

00 U  AMC Holiaday

01 A  OK. I understand that you’d like to get tickets for tonight. Can you tell me the city and state where the theater is located?

02 U  california

03 A  OK. And are you interested in AMC Mountain 16 or AMC Mercado 24?

04 U  AMC Mountain 16

05 A  Sorry for the trouble but I wanted to make sure I have it right.

06 U  OK.

07 A  Is there a particular movie you’re looking for?

08 U  timepass

09 A  OK, so far I understand that you are interested in tickets for tonight at AMC Mountain 16. We just need to decide on a movie, the number of tickets and a showtime.

10 U  AMC Mountain 16

11 A  I found two movies at AMC Mountain 16: No Time To Die and Mulan.

12 U  no time to die

13 A  Got it. And how many tickets?

14 U  3 tickets

15 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

16 U  confirm.

17 A  Is it OK to go ahead and purchase these tickets?

18 U  nice

## Q18

00 U  Hi, I'm looking to book tickets for a movie tonight.

01 A  OK. Can you tell me the city and state where the theater is located?

02 U  I'm glad to finally see the theaters open after so long. They have been closed everywhere.

03 A  Great. Can you tell me the city and state where you plan to see the movie?

04 U  Sure, it is in the Santa Barbara area of California.

05 A  Got it. Are you interested in a particular movie?

06 U  I think there are a bunch of different theaters near me.

07 A  OK. Is there a movie you have in mind?

08 U  Not off hand, I wouldn't mind a good action movie.

09 A  Ok. Let’s see what action films are out in that area.

10 A  I found one action movie at AMC Mountain 16: No Time To Die. Are you interested in that one?

11 U  I think everyone going would want a decent action flick, my best friend loves them. They are pretty much our go to pick.

12 A  OK. Are you interested in this movie though?

13 U  Yeah, sure. What show times are available?

14 A  OK. Remaining showtimes for No Time To Die at AMC Mountain 16 are 4:30pm, 6:40pm and 9:10pm.

15 U  I'll take the 9:10pm show.

16 A  Got it. And how many tickets?

17 U  I have three people going tonight including me.

18 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

19 U  I can't wait to finally see this film.

20 A  I hear you. Can you confirm the details are correct?

21 U  Yes, that's correct.

22 A  Awesome. Is it OK to go ahead and purchase these tickets?

23 U  Great! Thanks.

## Q19

00 U  I live in Spring Hills Kansas and I am looking for a movie theater nearby.

01 A  You have a Cinemark Downtown and an AMC Holiday theater in your area.

02 U  Can you tell me what is playing at the Cinemark?

03 A  For today?

04 U  Yes. Today please.

05 A  Beyond the Storm and Backcountry are both playing today.

06 U  Can you tell me about each movie?

07 A  Sure Beyond the Storm is about Fishing the North Sea gets ugly as Captain John’s crew faces not only severe weather but a traitor on board - directed by James Cameron.

08 U  And what is the other one about?

09 A  Backcountry is about Explore Yosemite in all its glory in this award winning film that delves into the wonders of one of the United State’s most iconic national parks.

10 U  What time is Beyond the Storm playing today?

11 A  At 1:30pm - 3:40 - 6:10pm - 8:30pm.

12 U  Can I get tickets for the 6:10 show please?

13 A  Yes. How many tickets do you want?

14 U  One.

15 A  So, one ticket for Beyond the Storm for 6:10 at the Cinemark Downtown? Is that correct?

16 U  Yes, it is.

17 A  Would you like me to place your order?

18 U  Yes I am.

## Q20

00 U  Hi, can you recommend some movies for me and my friend?

01 A  Sure, what kind of movies you and your friend would like?

02 U  We both like comedy and documentary genre.

03 A  No problem. Do you like Not My Problem? It is about a troubled teen trying to convince his depressed elderly neighbor that things are not what they seem. It is Starred by Matt Damon and Noah Schnapp.

04 U  It sounds interesting. Do you have more recommendation so that I can ask my friend to make a decision?

05 A  Sure. How about Backcountry? It is a documentary award winning film which explores Yosemite in all its glory and delves into the wonders of one of the United State’s most iconic national parks.

06 U  I love films exploring nature. How is the rating of the two films?

07 A  Not My Problem is rated PG-13 and Rotten Tomatoes gives a rating of 72%. Backcountry is rated G and Rotten Tomatoes gives a rating of 91%.

08 U  I just talked to my friend and we both decided to watch Backcountry. What is the showtime for tomorrow and the location of the cinema?

09 A  The showtimes are 4:10pm, 7:30pm and 10:15pm at Cinemark Downtown.

10 U  Great, I want 4:10pm.

11 A  How many tickets do you want?

12 U  Two.

13 A  Okay, so let me confirm the details with you. You want two tickets for Backcountry at 4:10pm tomorrow at Cinemark Downtown, right?

14 U  Correct.

15 A  Great, the cinema confirmed the booking is completed.

16 U  Thank you.

## Q21

00 A  Hello. How can I help you?

01 U  I wanna see the new James Bond movie

02 A  Happy to help! Let me just confirm that the movie name is No Time To Die. Is that right?

03 U  Yeah.

04 A  OK. Would you mind giving me the city and state where you’d like to see your movie?

05 U  In San Fran.

06 A  OK. San Francisco, California. One moment.

07 U  Ok.

08 A  OK. No Time To Die is currently playing at AMC Mountain 16 and Cinemark Plaza 24 in San Francisco, California. Do you have a preference?

09 U  I wanna see it at AMC Mountain 16.

10 A  OK. Let me check showtimes at AMC Mountain 16.

11 U  Okay.

12 A  Remaining showtimes for No Time To Die are 4:30pm, 6:40pm and 9:10pm.

13 U  I wanna go with 9:10pm.

14 A  Got it. And how many tickets?

15 U  I need three tickets.

16 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

17 U  yes.

18 A  Is it OK to go ahead and purchase these tickets?

19 U  Buy them.

## Q22

00 U  I'd like to see a film tonight

01 A  OK. And where will you be seeing the movie?

02 U  Something near me or that

03 A  OK. Can you give me the city and state?

04 U  Yeah creek end oregon

05 A  Creek’s End, Oregon. Got it. Is there a particular movie you have in mind?

06 U  That's james bond movie, the new one

07 A  Ok. I think you are talking about No Time To Die. Does that sound right?

08 U  Yep that's it

09 A  I think action movies are always a great choice. In Creek’s End, Oregon, I see that No Time To Die is showing in two theaters: AMC Mountain 16 and AMC Mercado 24.

10 U  Let's go with the second one is best

11 A  OK, AMC Mercado 24 it is.

12 U  What times?

13 A  It looks like tonight’s remaining showtimes for No Time To Die at AMC Mercado 24 are 5:00pm, 7:10pm, and 9:45pm. Which is best for you?

14 U  Please the first one

15 A  OK, so you'd like 5:00pm. And how many tickets?

16 U  me and my parents are going

17 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

18 U  Yep

19 A  Is it OK to go ahead and purchase these tickets?

20 U  Ok thanks

## Q23

00 U  Wow, I would love to see a movie tonight.

01 A  OK. And where will you be seeing the movie?

02 U  Well, near me would be great.

03 A  OK. Can you give me the city and state?

04 U  Creeks End, Oregon is where I would like to see the movie.

05 A  Creek’s End, Oregon. Got it. Is there a particular movie you have in mind?

06 U  The James Bond Movie is the one Id like to see.

07 A  Ok. I think you are talking about No Time To Die. Does that sound right?

08 U  No Time To Die, thats it.

09 A  I think action movies are always a great choice. In Creek’s End, Oregon, I see that No Time To Die is showing in two theaters: AMC Mountain 16 and AMC Mercado 24.

10 U  The second one will be great. Thanks.

11 A  OK, AMC Mercado 24 it is.

12 U  What times are there?

13 A  It looks like tonight’s remaining showtimes for No Time To Die at AMC Mercado 24 are 5:00pm, 7:10pm, and 9:45pm. Which is best for you?

14 U  The earlier one will work just fine.

15 A  OK, so you'd like 5:00pm. And how many tickets?

16 U  Well, my friend is going, my daughter is going, and I will be going.

17 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

18 U  Yes, that is right.

19 A  Is it OK to go ahead and purchase these tickets?

20 U  Yep, please purchase away.

## Q24

00 U  I would like to see a movie at AMC mountain 16

01 A  OK. I understand that you’d like to get tickets for tonight. Can you tell me the city and state where the theater is located?

02 U  Yes,Im in Santa Barbara, CA

03 A  OK. And are you interested in AMC Mountain 16 or AMC Mercado 24?

04 U  I said AMC mountain 16 in my first message already

05 A  Sorry for the trouble but I wanted to make sure I have it right.

06 U  OK.

07 A  Is there a particular movie you’re looking for?

08 U  sorry, but I'm in a hurry right now, can we speed this up?

09 A  OK, so far I understand that you are interested in tickets for tonight at AMC Mountain 16. We just need to decide on a movie, the number of tickets and a showtime.

10 U  Whats playing there?

11 A  I found two movies at AMC Mountain 16: No Time To Die and Mulan.

12 U  I'd like to watch No Time to Die

13 A  Got it. And how many tickets?

14 U  My, my brother, and his girlfriend will be attending

15 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

16 U  yes

17 A  Is it OK to go ahead and purchase these tickets?

18 U  yes, thatd be great, thank you

## Q25

00 U  Hello!

01 A  Hi, How r u?

02 U  fine, we are planning to go for a movie tonight.

03 A  Yeah, There is lot of movies running successfully. Which movie you want to go?

04 U  mm, Beyond the Storm

05 A  The Movie running in Cinemark Downtown.

06 U  cool, I want to go for Cinemark Downtown, what are the timings available at that theater

07 A  there are four timings right there. which are 1:30pm, 3:40pm, 6:10pm, 8:30pm

08 U  What are other some movies playing at the theater

09 A  There is another movies playing "Backcountry"

10 U  Any movies playing at AMC Holiday theater?

11 A  There are three movies playing at AMC Holiday theater which are "Not my Problem, family jewels, shuttered"

12 U  Ok thank You, I going for Beyond the storm at cinemark downtown,

13 A  Thank you sir, Which showtime you like to book your tickets? How many no. of tickets?

14 U  that is 8:30 pm, only two tickets

15 A  Ok sir, you have preferred two Beyond the storm movie tickets at cinemark downtown theater at 8:30 pm tonight. Do You confirm?

16 U  Yes, I confirm

17 A  Please pay the amount for the tickets,

18 U  yes sure

## Q26

00 U  Hi! Can you please tell me what movies are playing at the AMC Holiday Theater in Spring Hills, Kansas?

01 A  Sure! There are three movies playing right now: Not My Problem, Family Jewels, and Shuttered.

02 U  Is Shuttered a horror movie?

03 A  Yes. It's about a woman who moves upstate from her New York City lifestyle to work on her cousin’s haunted farm. It's rated R.

04 U  Is it any good?

05 A  Rotten Tomatoes gives it 61%.

06 U  Okay, how about The Family Jewels? What is that about?

07 A  It's a romantic comedy, about a diamond dealer from Antwerp who pursues a less than genuine romance with an American con artist. This one is also rated R.

08 U  Do you think this one would be good?

09 A  Rotten Tomatoes says 69%. But it stars Melissa McCarthy and Ryan Reynolds, so I would say that's a great comedy duo right there.

10 U  Great, thank you! What are the showtimes for Family Jewels?

11 A  That's playing at the AMC at 2:00, 5:00, and 8:10.

12 U  Okay, can I buy 2 tickets for today at 5:00?

13 A  Sure! So to confirm, you would like to purchase 2 tickets for The Family Jewels, at the AMC Holiday Theater in Spring Hills, for 5pm?

14 U  Yes, that is correct.

## Q27

00 U  Yeah, I'm in Spring Hills, Kansas. I want a number of all the movie theaters in the area, please.

01 A  I can help you with that, sir. I see two movie theaters in the Spring Hills, Kansas area.

02 U  Can I get names for both?

03 A  There's AMC Holiday Theater and Cinemark Downtown.

04 U  What recent movies are playing at the AMC?

05 A  AMC Holiday Theater is playing Not My Problem, Family Jewels, and Shuttered.

06 U  What about Cinemark?

07 A  Cinemark Downtown is playing Beyond the Storm and Backcountry.

08 U  What genre is Backcountry?

09 A  Backcountry is listed as a documentary.

10 U  What about Shuttered?

11 A  Shuttered is listed as a horror movie.

12 U  Are all the showtimes the same all week at the AMC Holiday Theater?

13 A  Yes, that's correct.

14 U  Get me one ticket for Shuttered on Wednesday. I want the showtime to be the 9:00pm.

15 A  So, you want one ticket for the 9:00pm showing of Shuttered at the AMC Holiday Theater on Wednesday?

16 U  Yeah, all that's right.

17 A  Is there anything else you need?

18 U  No, that's all for now from me.

## Q28

00 U  Hello!

01 A  Hi! How can I help you today?

02 U  This weather is driving me insane. Going stir crazy at home. My wife and I need a date night. What came out this week?

03 A  The Turning and The Gentlemen are the major releases this week?

04 U  The Gentlemen looks interesting. Getting good reviews?

05 A  Yes. 71% on Rotten Tomatoes with a 90% audience score.

06 U  Oh nice. Is it playing at the AMC in Lake in the Hills?

07 A  Yes, would you like me to book tickets for you?

08 U  Of course, anything about 6?

09 A  Unfortunately just 4:15 and 7:15.

10 U  Darn. What about the Cinemark at Spring Hill mall?

11 A  It isn't playing the the Cinemark at Spring Hill.

12 U  Wow. Okay, where else?

13 A  There is a 6:30 showing at the Regal in Crystal Lake.

14 U  Okay, that works.

15 A  Standard format. How many tickets?

16 U  Just 2

17 A  Let me confirm. 2 tickets for the 6:30 showing of The Gentlemen. Standard showing.

18 U  Yes.

## Q29

00 U  I need 2 movie tickets please

01 A  Sure which theater?

02 U  AMC Castleton Square 14 in Castleton, Indiana

03 A  Sounds good what movie do you want to see?

04 U  The wife wants to see Knives Out

05 A  Okay the showtime is 6:15 PM. Does that work for you?

06 U  Yes I think that it would.

07 A  Do you have a seating preference?

08 U  Please give us aisle seating.

09 A  Okay so do you want me to book the movie for 6:15PM?

10 U  No sorry my wife changed her mind and my wife now wants to see Ford Vs Ferrari what time does it start?

11 A  The show starts at 6:40 PM

12 U  ood that works could you book tickets for me?

13 A  Would you still prefer aisle seats and two tickets?

14 U  Yes I would.

15 A  The ticket total comes to $22 would you like me to reserve your seats?

16 U  Yes please.

17 A  No problem. Any other specific request?

18 U  Not that I can think of.

## Q30

00 U  I need to go to the movie theater today.

01 A  Okay, do you have a date?

02 U  I do!

03 A  Nice, what time are you going?

04 U  3PM apparently.

05 A  Cool, what movie?

06 U  Parasite.

07 A  Screening type?

08 U  3D.

09 A  Any theater preference?

10 U  AMC please.

11 A  Okay so I have a ticket to Parasite at AMC 3D showing at 3PM, right?

12 U  Yes!

13 A  Okay, processing.

14 U  Thank you!

## Q31

00 A  Hello. How can I help you?

01 U  I need information on "the new James Bond movie.

02 A  Happy to help! Let me just confirm that the movie name is No Time To Die. Is that right?

03 U  yes, that's correct.

04 A  OK. Would you mind giving me the city and state where you’d like to see your movie?

05 U  Cisco.

06 A  OK. San Francisco, California. One moment.

07 U  thank you

08 A  OK. No Time To Die is currently playing at AMC Mountain 16 and Cinemark Plaza 24 in San Francisco, California. Do you have a preference?

09 U  AMC Mountain 16 please.

10 A  OK. Let me check showtimes at AMC Mountain 16.

11 U  thank you.

12 A  Remaining showtimes for No Time To Die are 4:30pm, 6:40pm and 9:10pm.

13 U  9:10pm please.

14 A  Got it. And how many tickets?

15 U  I will need three tickets please.

16 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

17 U  Yes, that is correct.

18 A  Is it OK to go ahead and purchase these tickets?

19 U  Yes, please purchase.

## Q32

00 U  I would like to see a movie.

01 A  Great, what kind.

02 U  I'm in the mood for horror.

03 A  The latest horror movie showing is Shuttered.

04 U  What is it rated?

05 A  Shuttered is rated R.

06 U  What is it rated on Rotten Tomatoes?

07 A  61%

08 U  What other movies are rated high on Rotten Tomatoes?

09 A  Beyond The Storm, Rotten Tomatoes 81% and Backcountry with Documentary (outdoor), Rotten Tomatoes 91%.

10 U  What is Backcountry?

11 A  Backcountry - Documentary (outdoor) - rated G - Rotten Tomatoes 91% - Explore Yosemite in all its glory in this award winning film that delves into the wonders of one of the United State’s most iconic national parks.

12 U  What is the showing times for Backcountry?

13 A  Backcountry: Cinemark Downtown - 4:10pm - 7:30pm - 10:15pm

14 U  Where is Shuddered showing at?

15 A  Shuttered: AMC Holiday Theater - 3:00pm - 5:45 - 9:00pm

16 U  Where is Backcountry showing at?

17 A  Cinemark Downtown

18 U  Get me two tickets to Shuttered at the AMC Holiday Theatre at 9:00pm for later this evening.

## Q33

00 U  Hi, I'd like to get some information on films in my area.

01 A  Sure thing. What is your location?

02 U  I'm in Spring Hills Kansas.

03 A  Okay, got it. Now what information did you want to look up?

04 U  I wanted to see if you tell me what a couple of films are about.

05 A  Sure, I can do that. What are the film titles?

06 U  The first one I want to know about is a movie called Shuttered.

07 A  Okay, Shuttered is a horror film about a woman that moves upstate from her New York City lifestyle to work on her distant cousin’s haunted marijuana farm.

08 U  Okay, and the second is called Not My Problem.

09 A  Not My Problem is about a troubled teen that tries to convince his depressed elderly neighbor that things are not what they seem.

10 U  Is that a drama or something?

11 A  Not My Problem is a Comedy.

12 U  Oh, okay. Which of the films has a higher audience score?

13 A  Not My Problem has the higher score of 72%, Shuttered has a score of 61%.

14 U  I'd much rather the horror movie. I'll take a chance and get tickets for Shuttered.

15 A  Okay. I do have a theater in your area playing Shuttered. It's the AMC Holiday Theater. The show times are 3:00pm, 5:45 and 9:00pm.

16 U  I'll take two tickets for the 9pm show.

17 A  You have 2 tickets to see Shuttered at the AMC Holiday theater at 9pm tonight.

18 U  Correct.

## Q34

00 U  Hi I wanna see a film

01 A  what kind of movie?

02 U  comedy

03 A  what city are you in?

04 U  spring hills, kansas

05 A  do you care about the rating?

06 U  not at all

07 A  I have Not My Problem. That is with Matt Damon and is about a troubled teen. The other is Family Jewels. That is a romantic comedy with Melissa McCarthy. Family Jewels is rated R and the other is PG-13.

08 U  I like Melissa McCarthy so I will go with Family Jewels.

09 A  The theater it is playing at is called AMC Holiday Theater

10 U  showtimes please

11 A  2, 5 and 8:10 PM

12 U  I will go with the 2 PM

13 A  How many people?

14 U  2 please

15 A  would you like these emailed to you?

16 U  yes please

17 A  So Family Jewels at 2 PM for two people at AMC Holiday Theater correct? Also, what is your email?

18 U  yes fhsssss@gmail.com

## Q35

00 U  I think seeing a movie this night would be fun.

01 A  OK. And where will you be seeing the movie?

02 U  Some where not too far, Creek's End, Oregon, maybe

03 A  Creek’s End, Oregon. Got it. Is there a particular movie you have in mind?

04 U  Any movie that have kids authors like Mulan

05 A  Sure. Disney seems like a great choice. In Creek’s End, Oregon, I see that Mulan is showing in two theaters: AMC Mountain 16 and AMC Mercado 24.

06 U  I would not want to go far tonight so the second option is better.

07 A  No problem. It looks like tonight’s remaining showtimes for Mulan at AMC Mercado 24 are 5:00pm, 7:10pm, and 9:45pm. Which is best for you?

08 U  The first showtime will be great.

09 A  Great. And how many tickets?

10 U  We are three that are coming.

11 A  All right. Let me confirm that you’d like three tickets for Mulan at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

12 U  That's right.

13 A  Is it OK to go ahead and purchase these tickets?

14 U  Yes, please.

## Q36

00 U  Hi Am interested to but movie tickets at AMC Mountain 16

01 A  No problem. Is there a particular type of movie you’re looking for?

02 U  Yes i should be an action movie

03 A  Sure. I can help with that. Let me check listings at AMC Mercado 24.

04 U  sorry you were mistaken i mentioned AMC Mountain 16

05 A  Oh, sorry about that. So you’re interested in action films at AMC Mountain 16, right?

06 U  right

07 A  OK. I see one action movie playing at AMC Mountain 16: No Time To Die. Remaining showtimes are 4:30pm, 6:40pm and 9:10pm. Does any of those work?

08 U  okay go-ahead

09 A  Great. And how many tickets?

10 U  For 3 adults

11 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

12 U  yes please

13 A  Is it OK to go ahead and purchase these tickets?

14 U  Sure you can

## Q37

00 U  Hello, I would like to purchase movie tickets please.

01 A  What movie do you want to see?

02 U  I want to see Possession.

03 A  And what theater would you like to go to?

04 U  Which theater has the latest showtime?

05 A  There is Northgate Cinemas 12, or Cima Ultraplex 20.

06 U  Which theater has the latest showtime?

07 A  Northgate Cinemas 12 has a showtime at 10:25pm, otherwise there is an 8:30pm at Cima Ultraplex 20.

08 U  10:25pm at Northgate please, I want to go the latest showtime that day.

09 A  Great, and how many tickets did you need?

10 U  2 please, I am going with my mom.

11 A  And which day did you want to go?

12 U  Today please!

13 A  Is there anything else I can do?

14 U  No, that's it.

15 A  So to confirm, that is 2 tickets to the 10:25pm showing of Possession at the Northgate Cinemas 12 for tomorrow?

16 U  No, I want the tickets for today!

17 A  My mistake, 2 tickets to the 10:25pm showing of Possession at the Northgate Cinemas 12 for today?

18 U  Yes, that is correct!

## Q38

00 U  Hai.

01 A  Hello. How can i help you?

02 U  i'm looking for tickets to the movie. could you help to book the tickets?

03 A  of-course yes. what type of movie did you like?

04 U  i planned to watch a movie named shuttered

05 A  yes. The tickets are available to Shuttered

06 U  That's good. could you please tell me the name and timing of the theater

07 A  The theater name is AMC Holiday Theater - 3:00 pm - 5:45 - 9:00 pm

08 U  sounds well. i already experienced about that theater.

09 A  could you please tell me what time is best for you?

10 U  yeah. i choose 3.00 pm. that's only better for me

11 A  okay. how many tickets did you want?

12 U  i planned to go to that movie with my partner. so totally two tickets i want.

13 A  okay. can i book two tickets for you?

14 U  yeah. i confirm

## Q39

00 U  I got an itch to see a movie tonight, can you help?

01 A  OK. And where will you be seeing the movie?

02 U  Creek's End, Oregon

03 A  Creek’s End, Oregon. Got it. Is there a particular movie you have in mind?

04 U  Well I need something that the kids can see so how about Mulan?

05 A  Sure. Disney seems like a great choice. In Creek’s End, Oregon, I see that Mulan is showing in two theaters: AMC Mountain 16 and AMC Mercado 24.

06 U  Well the Mercado 24 is a lot closer so let's go with that.

07 A  No problem. It looks like tonight’s remaining showtimes for Mulan at AMC Mercado 24 are 5:00pm, 7:10pm, and 9:45pm. Which is best for you?

08 U  5 PM sounds great

09 A  Great. And how many tickets?

10 U  Myself and my two kids, so three.

11 A  All right. Let me confirm that you’d like three tickets for Mulan at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

12 U  Perfect.

13 A  Is it OK to go ahead and purchase these tickets?

14 U  Yes please.

## Q40

00 U  Would like to see the onward tonight

01 A  Great I can help with that. Can you give more details

02 U  Yes 2 Adults in evening today in standard screening. Any close cinema hall

03 A  I see the movie is playing in Exton in Movie tavern at 7.30 PM would that work. The movie is in standard screening

04 U  This should good. Please book the tickets

05 A  Ok confirming 2 Adults ticket for Onward tonight at 7.30 PM in standard screening at Movie Tavern in Exton

06 U  Actually let me check with kids

07 A  Not a problem I am waiting

08 U  Checked with kids and they also want to come. Please book 4 tickets 2 Adults and 2 Kids

09 A  Ok confirming 2 Adults and 2 kids ticket for Onward tonight at 7.30 PM in standard screening at Movie Tavern in Exton

10 U  This should good.

11 A  Any preferred seating arragnment

12 U  Yes the middle rows

## Q41

00 U  I want to watch a movie

01 A  in theater or at home?

02 U  In theater, but on that topic, turn on mission impossible on tv for me

03 A  all right, do you know what movie you want to watch on theater?

04 U  I want to watch parasite

05 A  I heard it was a decent movie and won a few awards

06 U  it did, and it is a foreign film too

07 A  how many ticket do you want

08 U  just 1

09 A  where do you want to watch the movie?

10 U  landmark 81

11 A  what time

12 U  9 pm tonight

13 A  what screen type?

14 U  the best they have at that time, imax, 3d or regular

15 A  anything else?

16 U  change the ticket to two tickets

17 A  to confirm, 2 tickets for parasite at landmark 81 tonight at 9 pm on imax

18 U  Correct

## Q42

00 U  I need movie tickets for tomorrow night

01 A  What theater are you interested in?

02 U  AMC Classic

03 A  Okay, and what film are you interested in?

04 U  Birds of Prey

05 A  What time works best for you?

06 U  4:00 PM

07 A  And how many tickets do you need?

08 U  3, please

09 A  Okay, I'm placing an order for 3 tickets for Bad Boys for Life at the AMC Classic for 4:00 PM

10 U  Wait, I said Birds of Prey. Not Bad Boys for Life.

11 A  Oh. I'm sorry.

12 U  It's okay. Just get them for Birds of Prey

13 A  You said Birds of Prey?

14 U  Yes, Birds of Prey

15 A  Ok, I'm placing an order for 3 tickets to Birds of Prey at 4 PM tomorrow at AMC Classic.

16 U  Thank you

## Q43

00 U  I would like to buy 2 movie tickets.

01 A  OK, I can help with that. Do you have a theater location in mind.

02 U  Yes, a AMC theater in Spring Hills Kansas

03 A  Ok, Do you have a particular movie in mind.

04 U  Not really but I'd like to see a comedy tomorrow.

05 A  I have 2 movies that meet that criteria: Family Jewels and Not My Problem.

06 U  What are the reviews for those movies

07 A  Family Jewels has a rotten tomato score of 69% and Not My Problem has a score of 72%

08 U  Are they rated PG

09 A  Not My Problem is a comedy; rated PG-13 and Family Jewels is a romantic comedy; rated R

10 U  Who is starring in the movie Not My Problem?

11 A  The stars are Matt Damon and Noah Schnapp.

12 U  Ok, I'd like to see Not My Problem around lunchtime.

13 A  Is is showing at 1PM? Would you like to book 2 tickets?

14 U  Yes please.

15 A  OK, I am reserving 2 tickets for 1PM showing of Not My Problem at the Spring Hills Kansas AMC theater tomorrow. Is that correct.

16 U  Yes, that is correct

## Q44

00 U  I would like to buy movie tickets for tonight

01 A  OK. Can you tell me the city and state where the theater is located?

02 U  I am really excited to finally go and see a movie

03 A  Great. Can you tell me the city and state where you plan to see the movie?

04 U  I am in Santa Barbara, CA

05 A  Got it. Are you interested in a particular movie?

06 U  I think we have more than one movie theater here.

07 A  OK. Is there a movie you have in mind?

08 U  I would prefer an action movie

09 A  Ok. Let’s see what action films are out in that area.

10 A  I found one action movie at AMC Mountain 16: No Time To Die. Are you interested in that one?

11 U  Actually, these movies seem to be super popular right now, even my best friend prefers this genre

12 A  OK. Are you interested in this movie though?

13 U  yes, but can you tell me more about it?

14 A  OK. Remaining showtimes for No Time To Die at AMC Mountain 16 are 4:30pm, 6:40pm and 9:10pm.

15 U  I'll do the 9:10 pm show

16 A  Got it. And how many tickets?

17 U  it's just me and my two friends

18 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

19 U  That's awesome, I can't wait!

20 A  I hear you. Can you confirm the details are correct?

21 U  Oh yes all good!

22 A  Awesome. Is it OK to go ahead and purchase these tickets?

23 U  Yes please

## Q45

00 U  I'd like to watch a movie.

01 A  What movie do you want to see?

02 U  I'm not sure yet. I was hoping you'd help me figure it out.

03 A  What movie do you want to know more about?

04 U  Who are the actors in Not My Problem?

05 A  Matt Damon and Noah Schnapp are the stars of Not My Problem.

06 U  Hmm. And what is Shuttered about?

07 A  The synopsis for Shuttered is Sarah Decker moves upstate from her New York City lifestyle to work on her distant cousin’s haunted marijuana farm.

08 U  That sounds fun. I'll pick Shuttered then.

09 A  What theater would you like to go to?

10 U  AMC Holiday Theater.

11 A  The available showtimes today there are 3:00pm - 5:45 - 9:00pm.

12 U  9:00pm it is then.

13 A  How many tickets will you need?

14 U  Just two.

15 A  Two tickets to see Shuttered at AMC Holiday Theater today at 9:00pm. Is this what you want?

16 U  Yes it is.

17 A  Would you like me to order the tickets?

18 U  Yes please.

## Q46

00 U  I want to go to the movies later today

01 A  Sure. What movie would you like to see?

02 U  Can you check what is playing at Boulevard 14 in Petaluma?

03 A  OK. Boulevard 14 Cinema in Petaluma, California is showing three movies: No Time To Die, Mulan, and Emma.

04 U  Can you show me what Mulan is about?

05 A  Sure. What specifically would you like to know?

06 U  Do you have a plot summary of the story?

07 A  OK. Here’s the synopsis of Mulan: Accompanied by her dragon, Mushu, Mulan uses her smarts to help ward off a Hun invasion, falling in love with a dashing captain along the way.

08 U  Are the ratings good for the movie?

09 A  Mulan has an 87% Rotten Tomatoes score and a 92% audience rating.

10 U  Hmm, thanks for the info. I think I want to see No Time To Die instead. What's the showtimes?

11 A  OK. No Time To Die is playing 4:00pm, 7:30pm, and 10:55pm. Which time would you like?

12 U  The 10:55 time sounds great. It'll be just my friend and I so order tickets for us please

13 A  All right. Let me confirm that you’d like two tickets for No Time To Die at Boulevard 14 Cinema tonight at 10:55pm. Is that all correct?

14 U  Yes that is correct.

15 A  Is it OK to go ahead and purchase these tickets?

16 U  Yes order them please

## Q47

00 U  I need to reserve tickets for a movie on Tuesday afternoon.

01 A  Okay, what film are you interested in seeing?

02 U  I' like to see Bad Boys For life. I want to see it around 3pm if possible.

03 A  What location are you interested in seeing the film?

04 U  At the 42nd street AMC theater.

05 A  I'll check show times for Tuesday.

06 U  Make sure it's afternoon times please.

07 A  Bad Boys for Life starts playing at the 42nd street theater at noon and continues on till 4pm.

08 U  What are the exact show times?

09 A  12:00pm, 2pm, 3:15pm and 4pm.

10 U  That's great, I'll take a 2pm show time.

11 A  How many tickets would you like to reserve?

12 U  I need two tickets in standard view.

13 A  I'm adding that to your cart now.

14 U  Can you tell me if that show time has a 3D option?

15 A  Yes, it does.

16 U  Can I change my viewing to 3D instead of standard?

17 A  Yes, I edited your order to two tickets to see Bad Boys for Life on Tuesday afternoon at 2pm.

18 U  Okay, I'll pay with credit card now.

## Q48

00 U  Hello, I want to go to the movies tonight. Help me out, can you?

01 A  You know I can! Where are you located?

02 U  I will be in Spring Hills, Kansas for the movie. Oh, tonight. I want to find one tonight to take my wife to.

03 A  No problem. There are two theaters in Spring Hills, Kansas. The AMC Holiday Theater and the Cinemark Downtown.

04 U  Ok, wow, I didn't know that, but we're just there for our anniversary. Let's see what's playing at the Cinemark Downtown.

05 A  Of course! The two films playing at the Cinemark downtown is BEYOND THE STORM and BACKCOUNTRY.

06 U  Never heard of either of them, can you tell me what BACKCOUNTRY is about?

07 A  BACKCOUNTRY:Documentary (outdoor) - rated G - Rotten Tomatoes 91% - Explore Yosemite in all its glory in this award winning film that delves into the wonders of one of the United State’s most iconic national parks.

08 U  Ok, what's BEYOND THE STORM about?

09 A  BEYOND THE STORM: Action - rated PG-13 - Rotten Tomatoes 81% - Fishing the North Sea gets ugly as Captain John’s crew faces not only severe weather but a traitor on board - directed by James Cameron.

10 U  Well, my wife loves James Cameron's films. What times is it showing tonight?

11 A  The showtimes today are 1:30pm - 3:40 - 6:10pm - 8:30pm.

12 U  Hang on, let me see what time our anniversary meal is so I can get this right.

13 A  No problem, take your time.

14 U  Wife says that 8:30PM is perfect. Get me two tickets for BEYOND THE STORM at the Cinemark Downtown for tonight, please. And I want them sent to my email address.

15 A  Just to be clear, you want two tickets for BEYOND THE STORM at the Cinemark Downtown for tonight at 8:30pm.

16 U  That's right!