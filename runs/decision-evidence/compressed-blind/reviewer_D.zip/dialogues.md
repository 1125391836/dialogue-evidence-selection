# TicketTalk 场次盲审

## V01

00 A  You know I can! Where are you located?

01 A  No problem, take your time.

02 U  Wife says that 8:30PM is perfect. Get me two tickets for BEYOND THE STORM at the Cinemark Downtown for tonight, please. And I want them sent to my email address.

03 A  Just to be clear, you want two tickets for BEYOND THE STORM at the Cinemark Downtown for tonight at 8:30pm.

04 U  That's right!

## V02

00 A  Great. And how many tickets?

01 U  We are three that are coming.

02 A  All right. Let me confirm that you’d like three tickets for Mulan at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

03 U  That's right.

04 A  Is it OK to go ahead and purchase these tickets?

05 U  Yes, please.

## V03

00 A  I found two movies at AMC Mountain 16: No Time To Die and Mulan.

01 U  no time to die

02 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

03 U  confirm.

04 A  Is it OK to go ahead and purchase these tickets?

05 U  nice

## V04

00 U  3, please

01 A  Oh. I'm sorry.

02 U  It's okay. Just get them for Birds of Prey

03 A  You said Birds of Prey?

04 U  Yes, Birds of Prey

05 A  Ok, I'm placing an order for 3 tickets to Birds of Prey at 4 PM tomorrow at AMC Classic.

06 U  Thank you

## V05

00 U  I want to see Possession.

01 U  2 please, I am going with my mom.

02 U  Today please!

03 A  So to confirm, that is 2 tickets to the 10:25pm showing of Possession at the Northgate Cinemas 12 for tomorrow?

04 A  My mistake, 2 tickets to the 10:25pm showing of Possession at the Northgate Cinemas 12 for today?

05 U  Yes, that is correct!

## V06

00 U  Wait. I need 1 senior ticket, too. Order 1 adult, 1 senior and 2 child tickets for Sunday the 26th.

01 U  Yes. Use my preferred Visa card.

02 A  Confirming one adult ticket at $11.70 each; one senior ticket and 2 child tickets at $8.50 each, with an added $7.16 convenience fee for a total preferred Visa charge of $44.36. Shall I complete payment?

03 U  Yes. No gift cards or promo codes.

## V07

00 U  Sometime between 7 and 8PM.

01 A  How many tickets will you need?

02 U  I just need 2 tickets.

03 A  Ok, so I found a 7:30PM showing for Backcountry playing at Cinemark Downtown, does that sound ok?

04 U  Yup, that's perfect!

05 A  Would you like me to book those?

06 U  Yes please.

## V08

00 U  fine, we are planning to go for a movie tonight.

01 U  Any movies playing at AMC Holiday theater?

02 U  Ok thank You, I going for Beyond the storm at cinemark downtown,

03 U  that is 8:30 pm, only two tickets

04 A  Ok sir, you have preferred two Beyond the storm movie tickets at cinemark downtown theater at 8:30 pm tonight. Do You confirm?

05 U  yes sure

## V09

00 U  At the 42nd street AMC theater.

01 U  Can you tell me if that show time has a 3D option?

02 A  Yes, it does.

03 U  Can I change my viewing to 3D instead of standard?

04 A  Yes, I edited your order to two tickets to see Bad Boys for Life on Tuesday afternoon at 2pm.

05 U  Okay, I'll pay with credit card now.

## V10

00 U  Yes, let's see if there's a similar time we can go see that instead.

01 A  Showtimes for Mulan are 4:00pm, 6:10pm, 8:30pm, and 10:40pm.

02 U  4PM is perfect!

03 A  Ok, can you confirm that you would like to purchase 2 tickets to Mulan at Mountain AMC 16 at 4PM?

04 U  Yes, confirmed!

## V11

00 A  Hi! How can I help you today?

01 U  Oh nice. Is it playing at the AMC in Lake in the Hills?

02 U  Okay, that works.

03 A  Standard format. How many tickets?

04 U  Just 2

05 A  Let me confirm. 2 tickets for the 6:30 showing of The Gentlemen. Standard showing.

06 U  Yes.

## V12

00 U  Yes. Today please.

01 U  What time is Beyond the Storm playing today?

02 A  Yes. How many tickets do you want?

03 U  One.

04 A  So, one ticket for Beyond the Storm for 6:10 at the Cinemark Downtown? Is that correct?

05 U  Yes, it is.

06 A  Would you like me to place your order?

07 U  Yes I am.

## V13

00 A  No problem. It looks like tonight’s remaining showtimes for Mulan at AMC Mercado 24 are 5:00pm, 7:10pm, and 9:45pm. Which is best for you?

01 A  All right. Let me confirm that you’d like three tickets for Mulan at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

02 A  Is it OK to go ahead and purchase these tickets?

03 U  Yeah.okay.

## V14

00 A  Unfortunately we just have it on standard screening.

01 U  Standard screening is fine.

02 A  So let me reserve you 2 tickets for The Gentlemen on standard screening at Movie Tavern West 7th at the 9:00 PM show.

03 U  Great! My mom will surely love that.

04 A  I am booking it as we speak. Your confirmation is 12345.

05 U  Thank you.

## V15

00 U  3

01 A  Sure thing, give me just a moment.

02 U  Okay.

03 A  Alright I now have 3 tickets to see Sonic the Hedgehog at 3pm Friday afternoon. The movie is showing at the AMC and you want to see it in IMAX. Correct?

04 U  Yep! Please book them.

05 A  Give me one moment.

06 U  Okay. Thanks.

## V16

00 A  Okay so do you want me to book the movie for 6:15PM?

01 U  No sorry my wife changed her mind and my wife now wants to see Ford Vs Ferrari what time does it start?

02 U  Yes I would.

03 A  The ticket total comes to $22 would you like me to reserve your seats?

04 U  Yes please.

05 A  No problem. Any other specific request?

06 U  Not that I can think of.

## V17

00 A  I found one action movie at AMC Mountain 16: No Time To Die.

01 U  when is No Time to Die playing?

02 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

03 U  yes, I'll confirm that.

04 A  Is it OK to go ahead and purchase these tickets?

05 U  Yes please.

## V18

00 A  OK. Remaining showtimes for No Time To Die at AMC Mountain 16 are 4:30pm, 6:40pm and 9:10pm.

01 U  I'll take the 9:10pm show.

02 A  I hear you. Can you confirm the details are correct?

03 U  Yes, that's correct.

04 A  Awesome. Is it OK to go ahead and purchase these tickets?

05 U  Great! Thanks.

## V19

00 U  What time is shuttered playing today?

01 A  2:00pm - 5:00pm - 8:10pm

02 U  Lets go with Family Jewels at 2pm.

03 A  How many tickets would you like?

04 U  3

05 A  Are you ready for me to purchase three tickets to see Family Jewels at 2pm today at AMC Holiday Theater?

06 U  Yes, make the purchase.

## V20

00 A  OK. I see one action movie playing at AMC Mountain 16: No Time To Die. Remaining showtimes are 4:30pm, 6:40pm and 9:10pm. Does any of those work?

01 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

02 A  Is it OK to go ahead and purchase these tickets?

03 U  Sure you can

## V21

00 U  Cinemark downtown

01 A  Tonight is playing Back Country and Beyond the storm

02 U  Let's do 6:10 pm please

03 A  Just to confirm thats 3 tickets today at the Cinemark Downtown cinema 6:10 pm viewing time of Beyond the Storm, are these details correct?

04 U  Yes thank you

05 A  Provide your email for confirmation

06 U  info@info.com

## V22

00 A  OK, so you'd like 5:00pm. And how many tickets?

01 U  me and my parents are going

02 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

03 U  Yep

04 A  Is it OK to go ahead and purchase these tickets?

05 U  Ok thanks

## V23

00 U  OK.

01 A  Got it. And how many tickets?

02 U  My, my brother, and his girlfriend will be attending

03 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

04 U  yes

05 A  Is it OK to go ahead and purchase these tickets?

06 U  yes, thatd be great, thank you

## V24

00 U  2 please.

01 A  There are no IMAX showings for Star wars at that time.

02 U  How about other screening types?

03 A  There is one for 3D and standard.

04 U  I'll take the 3D one instead then.

05 A  I'll go ahead and book the 2 tickets for the 8:30 showing for Star wars 3D screening.

06 U  Yes thank you.

## V25

00 U  Are the ratings good for the movie?

01 A  Mulan has an 87% Rotten Tomatoes score and a 92% audience rating.

02 U  Hmm, thanks for the info. I think I want to see No Time To Die instead. What's the showtimes?

03 U  Yes that is correct.

04 A  Is it OK to go ahead and purchase these tickets?

05 U  Yes order them please

## V26

00 A  Not a problem I am waiting

01 U  Checked with kids and they also want to come. Please book 4 tickets 2 Adults and 2 Kids

02 A  Ok confirming 2 Adults and 2 kids ticket for Onward tonight at 7.30 PM in standard screening at Movie Tavern in Exton

03 U  This should good.

04 A  Any preferred seating arragnment

05 U  Yes the middle rows

## V27

00 U  Great, thank you! What are the showtimes for Family Jewels?

01 A  That's playing at the AMC at 2:00, 5:00, and 8:10.

02 U  Okay, can I buy 2 tickets for today at 5:00?

03 A  Sure! So to confirm, you would like to purchase 2 tickets for The Family Jewels, at the AMC Holiday Theater in Spring Hills, for 5pm?

04 U  Yes, that is correct.

## V28

00 A  Remaining showtimes for No Time To Die are 4:30pm, 6:40pm and 9:10pm.

01 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

02 U  Yes, that is correct.

03 A  Is it OK to go ahead and purchase these tickets?

04 U  Yes, please purchase.

## V29

00 U  Yes, just me and my girlfriend.

01 A  Sure, it looks like they are available. Would you like to buy them now.

02 U  Yes, I would like to put them on my credit card.

03 A  OK, so I have two tickets for tomorrow reserved for Family Jewels, at the AMC Holiday Theater for the 8:10pm showing. Is that correct? The total is $XX.XX.

04 U  Yes, that about sums it up. My credit card is XXXXXXXXX, expiration XX.XX. My email is XXXX@XXX.com

## V30

00 U  5 PM sounds great

01 A  Great. And how many tickets?

02 U  Myself and my two kids, so three.

03 A  All right. Let me confirm that you’d like three tickets for Mulan at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

04 U  Perfect.

05 A  Is it OK to go ahead and purchase these tickets?

06 U  Yes please.

## V31

00 U  Parasite.

01 A  Screening type?

02 U  3D.

03 A  Any theater preference?

04 U  AMC please.

05 A  Okay so I have a ticket to Parasite at AMC 3D showing at 3PM, right?

06 U  Yes!

07 A  Okay, processing.

08 U  Thank you!

## V32

00 U  The earlier one will work just fine.

01 U  Well, my friend is going, my daughter is going, and I will be going.

02 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

03 U  Yes, that is right.

04 A  Is it OK to go ahead and purchase these tickets?

05 U  Yep, please purchase away.

## V33

00 A  It is an action film.

01 A  The Rotten Tomatoes score for Not My Problem is 72%.

02 U  OK, can I get four tickets to see Not My Problem at AMC Holiday Theater for August 20, 2020 at 7:00 PM?

03 A  So to confirm, you want four tickets for Not My Problem at AMC Holiday Theater for the 7:00 PM showing on August 20, 2020, is that correct?

04 U  Yes, that is right. You can confirm the tickets.

## V34

00 U  showtimes please

01 U  I will go with the 2 PM

02 A  How many people?

03 U  2 please

04 A  would you like these emailed to you?

05 U  yes please

06 A  So Family Jewels at 2 PM for two people at AMC Holiday Theater correct? Also, what is your email?

07 U  yes fhsssss@gmail.com

## V35

00 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

01 U  I am so excited to see No Time to Die!

02 A  I hear you. Can you confirm the details are correct?

03 U  Oh, yes they are.

04 A  Awesome. Is it OK to go ahead and purchase these tickets?

05 U  Yeah, let's do it.

## V36

00 A  Not My Problem is a Comedy.

01 A  Not My Problem has the higher score of 72%, Shuttered has a score of 61%.

02 U  I'd much rather the horror movie. I'll take a chance and get tickets for Shuttered.

03 U  I'll take two tickets for the 9pm show.

04 A  You have 2 tickets to see Shuttered at the AMC Holiday theater at 9pm tonight.

05 U  Correct.

## V37

00 U  Okay.

01 A  Got it. And how many tickets?

02 U  I need three tickets.

03 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

04 U  yes.

05 A  Is it OK to go ahead and purchase these tickets?

06 U  Buy them.

## V38

00 A  I found one action movie at AMC Mountain 16: No Time To Die. Are you interested in that one?

01 U  Actually, these movies seem to be super popular right now, even my best friend prefers this genre

02 A  I hear you. Can you confirm the details are correct?

03 U  Oh yes all good!

04 A  Awesome. Is it OK to go ahead and purchase these tickets?

05 U  Yes please

## V39

00 U  No problem !

01 U  Party size is just two and what are my time slots for that movie?

02 A  Family Jewels: AMC Holiday Theater - 2:00pm - 5:00pm - 8:10pm.

03 U  Okay lets book two for 2 pm and that theater is close so that works.

04 A  Booking two for 2 pm and that theater is fine. Is that correct?

05 U  Yes perfect.

## V40

00 A  what time

01 U  9 pm tonight

02 A  what screen type?

03 U  the best they have at that time, imax, 3d or regular

04 A  anything else?

05 U  change the ticket to two tickets

06 A  to confirm, 2 tickets for parasite at landmark 81 tonight at 9 pm on imax

07 U  Correct

## V41

00 A  Not My Problem is playing at 1pm, 3:55pm, 7pm and 10:05pm.

01 U  I'll take the 7pm show times please.

02 A  Alright, how many tickets do you need?

03 U  Just one.

04 A  Great, Let me confirm your order. You have 1 ticket to see Not My Problem at the AMC Holiday theater at 7pm tonight right?

05 U  Yup, that's everything.

## V42

00 A  OK. Stella’s House is playing at the Milford Theater. Showtimes are 4:40pm, 7:10pm, and 9:30pm. Which one would you prefer?

01 U  yup.sorry urgent call from ofiice plase can you change tickets tomorrow

02 U  okay choose that time.

03 U  okay

04 A  Is it OK to go ahead and purchase these tickets?

05 U  ok good.

## V43

00 A  yes. The tickets are available to Shuttered

01 A  The theater name is AMC Holiday Theater - 3:00 pm - 5:45 - 9:00 pm

02 U  yeah. i choose 3.00 pm. that's only better for me

03 U  i planned to go to that movie with my partner. so totally two tickets i want.

04 A  okay. can i book two tickets for you?

05 U  yeah. i confirm

## V44

00 U  Yes, a AMC theater in Spring Hills Kansas

01 U  Ok, I'd like to see Not My Problem around lunchtime.

02 A  Is is showing at 1PM? Would you like to book 2 tickets?

03 U  Yes please.

04 A  OK, I am reserving 2 tickets for 1PM showing of Not My Problem at the Spring Hills Kansas AMC theater tomorrow. Is that correct.

05 U  Yes, that is correct

## V45

00 A  61%

01 A  Backcountry: Cinemark Downtown - 4:10pm - 7:30pm - 10:15pm

02 U  Where is Shuddered showing at?

03 A  Shuttered: AMC Holiday Theater - 3:00pm - 5:45 - 9:00pm

04 U  Where is Backcountry showing at?

05 A  Cinemark Downtown

06 U  Get me two tickets to Shuttered at the AMC Holiday Theatre at 9:00pm for later this evening.

## V46

00 U  Are all the showtimes the same all week at the AMC Holiday Theater?

01 U  Get me one ticket for Shuttered on Wednesday. I want the showtime to be the 9:00pm.

02 A  So, you want one ticket for the 9:00pm showing of Shuttered at the AMC Holiday Theater on Wednesday?

03 U  Yeah, all that's right.

04 A  Is there anything else you need?

05 U  No, that's all for now from me.

## V47

00 U  AMC Holiday Theater.

01 U  9:00pm it is then.

02 A  How many tickets will you need?

03 U  Just two.

04 A  Two tickets to see Shuttered at AMC Holiday Theater today at 9:00pm. Is this what you want?

05 U  Yes it is.

06 A  Would you like me to order the tickets?

07 U  Yes please.

## V48

00 A  The showtimes are 4:10pm, 7:30pm and 10:15pm at Cinemark Downtown.

01 U  Two.

02 A  Okay, so let me confirm the details with you. You want two tickets for Backcountry at 4:10pm tomorrow at Cinemark Downtown, right?

03 U  Correct.

04 A  Great, the cinema confirmed the booking is completed.

05 U  Thank you.