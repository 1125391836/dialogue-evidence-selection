# TicketTalk 场次盲审

## V01

00 U  Oh, okay. Which of the films has a higher audience score?

01 A  Okay. I do have a theater in your area playing Shuttered. It's the AMC Holiday Theater. The show times are 3:00pm, 5:45 and 9:00pm.

02 U  I'll take two tickets for the 9pm show.

03 A  You have 2 tickets to see Shuttered at the AMC Holiday theater at 9pm tonight.

04 U  Correct.

## V02

00 A  Thank you sir, Which showtime you like to book your tickets? How many no. of tickets?

01 U  that is 8:30 pm, only two tickets

02 A  Ok sir, you have preferred two Beyond the storm movie tickets at cinemark downtown theater at 8:30 pm tonight. Do You confirm?

03 U  Yes, I confirm

04 A  Please pay the amount for the tickets,

05 U  yes sure

## V03

00 A  Beyond the Storm has a PG-13 rating.

01 A  Yes, it is. Not My Problem plays at AMC Holiday Theater at 1:00 PM, 3:55 PM, 7:00 PM, and 10:05 PM.

02 A  So to confirm, you want four tickets for Not My Problem at AMC Holiday Theater for the 7:00 PM showing on August 20, 2020, is that correct?

03 U  Yes, that is right. You can confirm the tickets.

## V04

00 A  The latest horror movie showing is Shuttered.

01 U  What is the showing times for Backcountry?

02 U  Where is Shuddered showing at?

03 A  Shuttered: AMC Holiday Theater - 3:00pm - 5:45 - 9:00pm

04 U  Where is Backcountry showing at?

05 A  Cinemark Downtown

06 U  Get me two tickets to Shuttered at the AMC Holiday Theatre at 9:00pm for later this evening.

## V05

00 U  Can I get tickets for the 6:10 show please?

01 A  Yes. How many tickets do you want?

02 U  One.

03 A  So, one ticket for Beyond the Storm for 6:10 at the Cinemark Downtown? Is that correct?

04 U  Yes, it is.

05 A  Would you like me to place your order?

06 U  Yes I am.

## V06

00 U  Parasite.

01 A  Screening type?

02 U  3D.

03 A  Any theater preference?

04 U  AMC please.

05 A  Okay so I have a ticket to Parasite at AMC 3D showing at 3PM, right?

06 U  Yes!

07 A  Okay, processing.

08 U  Thank you!

## V07

00 A  The stars are Matt Damon and Noah Schnapp.

01 U  Ok, I'd like to see Not My Problem around lunchtime.

02 A  Is is showing at 1PM? Would you like to book 2 tickets?

03 U  Yes please.

04 A  OK, I am reserving 2 tickets for 1PM showing of Not My Problem at the Spring Hills Kansas AMC theater tomorrow. Is that correct.

05 U  Yes, that is correct

## V08

00 U  Are there any action movies playing?

01 A  OK. Remaining showtimes for No Time To Die at AMC Mountain 16 are 4:30pm, 6:40pm and 9:10pm.

02 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

03 U  Oh, yes they are.

04 U  Yeah, let's do it.

## V09

00 U  Sometime between 7 and 8PM.

01 A  How many tickets will you need?

02 U  I just need 2 tickets.

03 A  Ok, so I found a 7:30PM showing for Backcountry playing at Cinemark Downtown, does that sound ok?

04 U  Yup, that's perfect!

05 A  Would you like me to book those?

06 U  Yes please.

## V10

00 A  I have Not My Problem playing at AMC Holiday Theater in your area.

01 U  I'll take the 7pm show times please.

02 A  Alright, how many tickets do you need?

03 U  Just one.

04 A  Great, Let me confirm your order. You have 1 ticket to see Not My Problem at the AMC Holiday theater at 7pm tonight right?

05 U  Yup, that's everything.

## V11

00 A  You know I can! Where are you located?

01 A  No problem, take your time.

02 U  Wife says that 8:30PM is perfect. Get me two tickets for BEYOND THE STORM at the Cinemark Downtown for tonight, please. And I want them sent to my email address.

03 A  Just to be clear, you want two tickets for BEYOND THE STORM at the Cinemark Downtown for tonight at 8:30pm.

04 U  That's right!

## V12

00 U  The 10:55 time sounds great. It'll be just my friend and I so order tickets for us please

01 A  All right. Let me confirm that you’d like two tickets for No Time To Die at Boulevard 14 Cinema tonight at 10:55pm. Is that all correct?

02 U  Yes that is correct.

03 A  Is it OK to go ahead and purchase these tickets?

04 U  Yes order them please

## V13

00 U  5 PM sounds great

01 A  Great. And how many tickets?

02 U  Myself and my two kids, so three.

03 A  All right. Let me confirm that you’d like three tickets for Mulan at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

04 U  Perfect.

05 A  Is it OK to go ahead and purchase these tickets?

06 U  Yes please.

## V14

00 A  The last show tonight at Movie Tavern West 7th is at 9:00 PM.

01 U  I still have time. Book me for 2 please.

02 A  Any screening preference?

03 A  So let me reserve you 2 tickets for The Gentlemen on standard screening at Movie Tavern West 7th at the 9:00 PM show.

04 U  Great! My mom will surely love that.

05 U  Thank you.

## V15

00 U  showtimes please

01 U  I will go with the 2 PM

02 A  How many people?

03 U  2 please

04 A  would you like these emailed to you?

05 U  yes please

06 A  So Family Jewels at 2 PM for two people at AMC Holiday Theater correct? Also, what is your email?

07 U  yes fhsssss@gmail.com

## V16

00 U  Yes 2 Adults in evening today in standard screening. Any close cinema hall

01 A  I see the movie is playing in Exton in Movie tavern at 7.30 PM would that work. The movie is in standard screening

02 A  Ok confirming 2 Adults and 2 kids ticket for Onward tonight at 7.30 PM in standard screening at Movie Tavern in Exton

03 A  Any preferred seating arragnment

04 U  Yes the middle rows

## V17

00 U  What time is shuttered playing today?

01 A  2:00pm - 5:00pm - 8:10pm

02 U  Lets go with Family Jewels at 2pm.

03 A  How many tickets would you like?

04 U  3

05 A  Are you ready for me to purchase three tickets to see Family Jewels at 2pm today at AMC Holiday Theater?

06 U  Yes, make the purchase.

## V18

00 U  Is Shuttered a horror movie?

01 U  Is it any good?

02 U  Great, thank you! What are the showtimes for Family Jewels?

03 U  Okay, can I buy 2 tickets for today at 5:00?

04 A  Sure! So to confirm, you would like to purchase 2 tickets for The Family Jewels, at the AMC Holiday Theater in Spring Hills, for 5pm?

05 U  Yes, that is correct.

## V19

00 U  Hai.

01 A  could you please tell me what time is best for you?

02 U  yeah. i choose 3.00 pm. that's only better for me

03 A  okay. how many tickets did you want?

04 U  i planned to go to that movie with my partner. so totally two tickets i want.

05 A  okay. can i book two tickets for you?

06 U  yeah. i confirm

## V20

00 A  It looks like tonight’s remaining showtimes for No Time To Die at AMC Mercado 24 are 5:00pm, 7:10pm, and 9:45pm. Which is best for you?

01 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

02 A  Is it OK to go ahead and purchase these tickets?

03 U  Yep, please purchase away.

## V21

00 U  Any movie that have kids authors like Mulan

01 A  No problem. It looks like tonight’s remaining showtimes for Mulan at AMC Mercado 24 are 5:00pm, 7:10pm, and 9:45pm. Which is best for you?

02 A  All right. Let me confirm that you’d like three tickets for Mulan at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

03 U  Yes, please.

## V22

00 U  Hello. I'd like you to tell me what comedy or family movies are currently playing at Regal Cinema Harrisburg?

01 U  Okay. Book 1 adult and 2 child tickets for Spies in Disguise on Sunday at 3:25 PM, please.

02 A  Ordering 1 adult, 1 senior and 2 child tickets to the 3:25 PM showing of Spies in Disguise at Regal Cinema for Sunday, January 26th. Is that correct?

03 U  Yes. No gift cards or promo codes.

## V23

00 U  Hello!

01 U  Wow. Okay, where else?

02 A  There is a 6:30 showing at the Regal in Crystal Lake.

03 U  Okay, that works.

04 A  Standard format. How many tickets?

05 U  Just 2

06 A  Let me confirm. 2 tickets for the 6:30 showing of The Gentlemen. Standard showing.

07 U  Yes.

## V24

00 U  3, please

01 A  Oh. I'm sorry.

02 U  It's okay. Just get them for Birds of Prey

03 A  You said Birds of Prey?

04 U  Yes, Birds of Prey

05 A  Ok, I'm placing an order for 3 tickets to Birds of Prey at 4 PM tomorrow at AMC Classic.

06 U  Thank you

## V25

00 U  Yes, just me and my girlfriend.

01 A  Sure, it looks like they are available. Would you like to buy them now.

02 U  Yes, I would like to put them on my credit card.

03 A  OK, so I have two tickets for tomorrow reserved for Family Jewels, at the AMC Holiday Theater for the 8:10pm showing. Is that correct? The total is $XX.XX.

04 U  Yes, that about sums it up. My credit card is XXXXXXXXX, expiration XX.XX. My email is XXXX@XXX.com

## V26

00 U  okay go-ahead

01 A  Great. And how many tickets?

02 U  For 3 adults

03 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

04 U  yes please

05 A  Is it OK to go ahead and purchase these tickets?

06 U  Sure you can

## V27

00 U  2 please.

01 A  There are no IMAX showings for Star wars at that time.

02 U  How about other screening types?

03 A  There is one for 3D and standard.

04 U  I'll take the 3D one instead then.

05 A  I'll go ahead and book the 2 tickets for the 8:30 showing for Star wars 3D screening.

06 U  Yes thank you.

## V28

00 U  Hello, I want to go watch a movie in theaters today.

01 A  Great! Just to confirm, you would like to purchase 2 tickets to No Time to Die at Mountain AMC 16 at 3:00 PM?

02 U  4PM is perfect!

03 A  Ok, can you confirm that you would like to purchase 2 tickets to Mulan at Mountain AMC 16 at 4PM?

04 U  Yes, confirmed!

## V29

00 U  Okay.

01 A  Got it. And how many tickets?

02 U  I need three tickets.

03 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

04 U  yes.

05 A  Is it OK to go ahead and purchase these tickets?

06 U  Buy them.

## V30

00 U  Hmm. Let's do Standard.

01 A  Okay, so I have 3 tickets for Friday afternoon at 3pm to see Sonic the Hedgehog at the AMC in Standard. Is this correct?

02 A  Alright I now have 3 tickets to see Sonic the Hedgehog at 3pm Friday afternoon. The movie is showing at the AMC and you want to see it in IMAX. Correct?

03 A  Give me one moment.

04 U  Okay. Thanks.

## V31

00 A  Yes, that's correct.

01 U  Get me one ticket for Shuttered on Wednesday. I want the showtime to be the 9:00pm.

02 A  So, you want one ticket for the 9:00pm showing of Shuttered at the AMC Holiday Theater on Wednesday?

03 U  Yeah, all that's right.

04 A  Is there anything else you need?

05 U  No, that's all for now from me.

## V32

00 U  No problem !

01 U  Party size is just two and what are my time slots for that movie?

02 A  Family Jewels: AMC Holiday Theater - 2:00pm - 5:00pm - 8:10pm.

03 U  Okay lets book two for 2 pm and that theater is close so that works.

04 A  Booking two for 2 pm and that theater is fine. Is that correct?

05 U  Yes perfect.

## V33

00 A  what time

01 U  9 pm tonight

02 A  what screen type?

03 U  the best they have at that time, imax, 3d or regular

04 A  anything else?

05 U  change the ticket to two tickets

06 A  to confirm, 2 tickets for parasite at landmark 81 tonight at 9 pm on imax

07 U  Correct

## V34

00 U  I choose 5:00pm

01 A  Great. And how many tickets?

02 U  three

03 A  All right. Let me confirm that you’d like three tickets for Mulan at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

04 U  yes,correct.

05 A  Is it OK to go ahead and purchase these tickets?

06 U  Yeah.okay.

## V35

00 A  The viewing times today are 1:30pm - 3:40 - 6:10pm - 8:30pm

01 U  Let's do 6:10 pm please

02 A  Just to confirm thats 3 tickets today at the Cinemark Downtown cinema 6:10 pm viewing time of Beyond the Storm, are these details correct?

03 U  Yes thank you

04 A  Provide your email for confirmation

05 U  info@info.com

## V36

00 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

01 U  That's awesome, I can't wait!

02 A  I hear you. Can you confirm the details are correct?

03 U  Oh yes all good!

04 A  Awesome. Is it OK to go ahead and purchase these tickets?

05 U  Yes please

## V37

00 A  Got it. And how many tickets?

01 U  enough for me and two of my friends.

02 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

03 U  yes, I'll confirm that.

04 A  Is it OK to go ahead and purchase these tickets?

05 U  Yes please.

## V38

00 U  Great, I want 4:10pm.

01 A  How many tickets do you want?

02 U  Two.

03 A  Okay, so let me confirm the details with you. You want two tickets for Backcountry at 4:10pm tomorrow at Cinemark Downtown, right?

04 U  Correct.

05 A  Great, the cinema confirmed the booking is completed.

06 U  Thank you.

## V39

00 U  thank you.

01 A  Got it. And how many tickets?

02 U  I will need three tickets please.

03 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

04 U  Yes, that is correct.

05 A  Is it OK to go ahead and purchase these tickets?

06 U  Yes, please purchase.

## V40

00 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

01 U  I can't wait to finally see this film.

02 A  I hear you. Can you confirm the details are correct?

03 U  Yes, that's correct.

04 A  Awesome. Is it OK to go ahead and purchase these tickets?

05 U  Great! Thanks.

## V41

00 A  12:00pm, 2pm, 3:15pm and 4pm.

01 U  That's great, I'll take a 2pm show time.

02 A  Yes, it does.

03 U  Can I change my viewing to 3D instead of standard?

04 A  Yes, I edited your order to two tickets to see Bad Boys for Life on Tuesday afternoon at 2pm.

05 U  Okay, I'll pay with credit card now.

## V42

00 A  OK, so far I understand that you are interested in tickets for tonight at AMC Mountain 16. We just need to decide on a movie, the number of tickets and a showtime.

01 A  I found two movies at AMC Mountain 16: No Time To Die and Mulan.

02 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

03 U  yes, thatd be great, thank you

## V43

00 U  AMC Holiday Theater.

01 U  9:00pm it is then.

02 A  How many tickets will you need?

03 U  Just two.

04 A  Two tickets to see Shuttered at AMC Holiday Theater today at 9:00pm. Is this what you want?

05 U  Yes it is.

06 A  Would you like me to order the tickets?

07 U  Yes please.

## V44

00 U  last showing time?

01 A  Sure. The last showing is 9:30pm.

02 U  okay choose that time.

03 A  All right. Let me confirm. You’d like 4 tickets for the 9:30pm showing of Stella’s House at Milford Theater tomorrow. Is that all correct?

04 U  okay

05 A  Is it OK to go ahead and purchase these tickets?

06 U  ok good.

## V45

00 A  The show starts at 6:40 PM

01 U  ood that works could you book tickets for me?

02 A  Would you still prefer aisle seats and two tickets?

03 U  Yes I would.

04 A  The ticket total comes to $22 would you like me to reserve your seats?

05 U  Yes please.

06 A  No problem. Any other specific request?

07 U  Not that I can think of.

## V46

00 A  It looks like tonight’s remaining showtimes for No Time To Die at AMC Mercado 24 are 5:00pm, 7:10pm, and 9:45pm. Which is best for you?

01 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mercado 24 tonight at 5:00pm. Is that all correct?

02 A  Is it OK to go ahead and purchase these tickets?

03 U  Ok thanks

## V47

00 U  Today please!

01 U  No, that's it.

02 A  So to confirm, that is 2 tickets to the 10:25pm showing of Possession at the Northgate Cinemas 12 for tomorrow?

03 U  No, I want the tickets for today!

04 A  My mistake, 2 tickets to the 10:25pm showing of Possession at the Northgate Cinemas 12 for today?

05 U  Yes, that is correct!

## V48

00 U  no time to die

01 A  Got it. And how many tickets?

02 U  3 tickets

03 A  All right. Let me confirm that you’d like three tickets for No Time To Die at AMC Mountain 16 tonight at 9:10pm. Is that all correct?

04 U  confirm.

05 A  Is it OK to go ahead and purchase these tickets?

06 U  nice